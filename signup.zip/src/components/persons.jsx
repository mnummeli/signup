import React, { Component } from "react";
// import Counter from "./counter";

class Persons extends Component {
  render() {
    const { persons } = this.props;
    console.log(this.props);
    return (
      <div>

        {persons.map(person => (
          <Persons
            
          />
        ))}
      </div>
    );
  }
}

export default Counters;
